
//This file contains all keys used during the project - since these contain user data (password and username)
//This file is omitted from Github

module.exports = {
    mongoDB:{
      dbURI: 'mongodb://TestUser:67anzkdq8n48nMH@ds247061.mlab.com:47061/pilot_trust'
    }
}